
function imagechange(){

  document.getElementById("image").src="https://h7f7z2r7.stackpathcdn.com/sites/default/files/images/articles/italy-factories-1.jpg";

};